#include<stdio.h>

int main()
{
	char str[20];
	int i=0,count=0;
	printf("enter string:");
	scanf("%s",str);
	while(str[i]!='\0')
	{
		if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u')
		{
			count++;
		}
	i++;
	}

	printf("No of vowels in string: %d\n",count);
	return 0;	
}