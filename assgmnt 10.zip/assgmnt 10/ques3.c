#include<stdio.h>

int main()
{
	char str[20];
	int i=0;
	printf("enter string:");
	scanf("%s",str);
	while(str[i]!='\0')
	{
		if(str[i]>='a' && str[i]<='z')
		{
			str[i]=str[i]-32;
		}
	i++;
	}

	printf("string in uppercase: %s\n",str);
	return 0;


}