#include<stdio.h>

int main()
{
	char str[20];
	int i;
	printf("enter string:");
	scanf("%s",str);
	for(i=0;str[i]!='\0';++i);

	for(int j=i;j>=0;j--){
		printf("%c",str[j]);
	}
	printf("\n");
	return 0;
}