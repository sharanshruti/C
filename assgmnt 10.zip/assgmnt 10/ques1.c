#include<stdio.h>

int main()
{
	char s1[]="Hi hey";
	for(int i=0;i<6;i++)
		printf("%p\n",&s1[i]);


	return 0;

}