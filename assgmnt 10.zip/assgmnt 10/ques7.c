#include<stdio.h>
#include<string.h>

int main()
{
	char str[20];
	int i;
	printf("enter string:");	
	scanf("%s",str);

	int j=strlen(str);
	i=j-1;
	while(str[i]!='\0'){
		if(str[i]=' '){
			for(int k=i;k<=j;k++)
			{
				printf("%c",str[k]);
			}
		}
		j--;
	}

	return 0;

}