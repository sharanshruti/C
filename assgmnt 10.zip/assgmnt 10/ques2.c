#include<stdio.h>
#include <string.h>
int main()
{	
	//case 1
   char str1[50], str2[50], i, j,k;
   printf("Enter first string: ");
   scanf("%s",str1);
   printf("Enter second string: ");
   scanf("%s",str2);
   /* This loop is to store the length of str1 in i
    * It just counts the number of characters in str1
    * You can also use strlen instead of this.
    */
   for(i=0; str1[i]!='\0'; ++i); 
 
   /* This loop would concatenate the string str2 at
    * the end of str1
    */
   for(j=0; str2[j]!='\0'; ++j, ++i)
   {
      str1[i]=str2[j];
   }
   // \0 represents end of string
   str1[i]='\0';
   printf("String After Concatenation: %s\n",str1);
   

   //case 2
    printf("Enter first string: ");
    scanf("%s",str1);
    printf("Enter second string: ");
    scanf("%s",str2);   
 	strcat(str1,str2);
	printf("String After Concatenation : %s\n\n",str1);

	//case 3
    char s1[50], s2[50],k;
    printf("Enter first string: ");
    scanf("%s",s1);
    printf("Enter second string: ");
    scanf("%s",s2);
    for(k=0; s1[k]!='\0'; ++k){
    	if(s1[k]==s2[k])
    		printf("0");
    	else
    		printf("1");
	}
	printf("\n");

	//case4
	int z=strcmp(s1,s2);
	if(z==0){
		printf("strings are same.\n");
	}	
	else
		printf("strings are not same.\n");

	//case5
	printf("length of string s1 is %d\n",k);
	//case6
	int q=strlen(s1);
	printf("length of string s1 is %d\n",q);

	//case7
	char str3[10],str4[10],x,y;
	printf("enter string:");
	scanf("%s",str3);
	for(x=0;str3[x]!='\0';++x)
	for(y=0;y<=x;y++){
		str4[y]=str3[y];
	}
	printf("%s \n",str4);

	//case8
	strcpy(str4,str3);
	printf("%s \n",str4);	


}