#include<stdio.h>

int main()
{
	char str[20];
	int i,j=0,k;
	printf("enter string:");
	scanf("%s",str);
	for(i=0;str[i]!='\0';++i);

	while(i!=j){
		if(str[j]==str[i-1])
			k=0;
		else
			k=1;
		j++;
		i--;
	}
	if(k==0)
		printf("pallindrome string.\n");
	else
		printf("not a pallindrome.\n");

	return 0;


}