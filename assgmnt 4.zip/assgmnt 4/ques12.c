#include<stdio.h>
int main()
{
	int i;
	for(i=1;i<=10;i++)
	{
		int pro=8*i;
		printf("8*%d= %d\n",i,pro);
	}

	return 0;
}