#include<stdio.h>
int main()
{
	int n=5;
	for (int i=1;i<5;i++)
	{
		printf("\n");
	}
	printf("\n");
	return 0;
}