#include<stdio.h>
int main()
{
	int n=145;
	while(n>0)
		

}