#include<stdio.h>

int main()
{
	printf(" File: %s\n Date: %s\n Time: %s\n Function: %s\n Line: %d\n ",__FILE__,__DATE__,__TIME__,__FUNCTION__,__LINE__);

	return 0;
}
