#include<stdio.h>

int swap(int *pa, int *pb)
{
	*pa^=*pb;
	*pb^=*pa;
	*pa^=*pb;
}
int main()
{
	int a=2,b=3;
	int *pa=&a;
	int *pb=&b;
	swap(&a,&b);
	printf("%d %d\n",a,b);
	return 0;	

}