#include<stdio.h>
int main()
{
	int a=2,b=4;
	if(a>b){
		printf("a is max. %d\n",a);
	}else {
		printf("b is max. %d\n",b);
	}
	return 0;

}