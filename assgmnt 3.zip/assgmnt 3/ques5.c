#include<stdio.h>
int main()
{
	int n=-2;
	if (n>0){
		printf("Number is positive.\n");
	}else if (n==0){
		printf("Number is 0.\n");
	}else if(n<0){
		printf("NUmber is negative.\n");
	}
	return 0;
}