#include<stdio.h>

int main()
{
	int n=8;
	if (n%2==0){
		printf("Number is even.\n");
	}else{
		printf("Number is odd.");
	}
	return 0;



}