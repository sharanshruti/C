#include<stdio.h>
int lead(int a)
{
	int b= a%10;
	a=a/10;
	int c=a%10;
	a=a/10;
	int l= a%10;
	printf("The leading no is %d\n",l); 

}


int main()
{
	int n=123;
	lead(n);
	return 0;
}