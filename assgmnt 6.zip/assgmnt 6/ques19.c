#include<stdio.h>

int digits(int a)
{
	int count=0;
	while (a!=0)
	{
		a=a/10;
		++count;
	}
	return count;
}

int main()
{
	int n=24;
	int x = digits(n);
	printf("the number of digits in the number is %d\n",x);
	return 0;
}