#include<stdio.h>

int fact(int n)
{
	if (n==1)
		return 1;
	else
		return n*fact(n-1);

}
 int main()
 {
 	int a = 5;
 	int x=fact(a);
 	printf("%d factorial is %d\n",a,x);
 	return 0;
 }
