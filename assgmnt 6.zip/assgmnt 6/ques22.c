#include<stdio.h>
int gcd(int a,int b)
{
	if(b!=0)
		return gcd(b,a%b);
	else
		return a;
}

int main()
{
	int x=10,y=20;
	int z=gcd(x,y);
	printf("GCD of the two numbers is %d\n",z);
	return 0;
}