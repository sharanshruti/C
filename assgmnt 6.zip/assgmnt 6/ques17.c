#include<stdio.h>

int sumofeven(int a,int b)
{
	if (a>b)
		return 0;
	else if(a%2==0)
		return a+sumofeven(a+2,b);
	else
		return sumofeven(a+1,b);
}


int main()
{
	int x=1;
	int y=10;
	int z=sumofeven(x,y);
	printf("Sum of even numbers in range %d to %d is %d\n",x,y,z);
	return 0;

}