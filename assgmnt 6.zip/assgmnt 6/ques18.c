#include<stdio.h>

int sumofodd(int a,int b)
{
	if (a>b)
		return 0;
	else if(a%2!=0)
		return a+sumofodd(a+2,b);
	else
		return sumofodd(a+1,b);
}


int main()
{
	int x=1;
	int y=10;
	int z=sumofodd(x,y);
	printf("Sum of odd numbers in range %d to %d is %d\n",x,y,z);
	return 0;

}