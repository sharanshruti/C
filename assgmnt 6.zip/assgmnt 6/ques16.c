#include<stdio.h>

int exp1(int a, int b)
{
	if (b==1)
		return a;
	else
		return a* exp1(a,b-1);
}

int main(){
	int x=4;
	int n=3;
	int c=exp1(x,n);
	printf("%d raised to %d is %d\n",x,n,c);
	return 0;
}