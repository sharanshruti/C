#include<stdio.h>
int sum(int a)
{
	int s=0;
	for(int i=1;i<=a;i++){
		s+=i;
	}
	printf("%d is summation of the first %d natural numbers.\n",s,a );

}

int main()
{
	int n= 3;
	sum(n);
	return 0;
}