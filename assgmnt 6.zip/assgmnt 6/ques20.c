#include<stdio.h>
int sum(int a)
{
	if (a!=0)
	{
		return (a%10+sum(a/10));
	}
	else
		return 0;
}

int main()
{
	int n=123;
	int z= sum(n);
	printf("the sum of digits of number %d is %d\n",n,z);
	return 0;

}