#include<stdio.h>

int fibo(int a)
{
	if (a==0)
		return 0;
	else if (a==1)
		return 1;
	else
		return fibo(a-1)+fibo(a-2);
}

int main ()
{
	int n=6;
	int x= fibo(n-1);  /*check the number seq in series 0 is 1st */
	printf("The %dth number in fibonacci series is %d\n",n,x);
	return 0;
}