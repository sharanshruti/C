#include<stdio.h>
int x=0,s;
int rev(int a)
{
	if(a)
	{
		s=a%10;
		x=x*10+s;
		rev(a/10);
	}
	return x;
}

int main()
{
	int n=123;
	int z= rev(n);
	printf("The reverse of number %d is %d\n",n,z);
	return 0;
}