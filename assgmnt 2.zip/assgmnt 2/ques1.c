#include<stdio.h>

int main()
{
	char a = 'a';
	printf("the ascii value of a : %d \n",a);
	return 0;
}