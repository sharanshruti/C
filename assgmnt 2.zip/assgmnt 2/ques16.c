#include<stdio.h>
int main()
{
	int num=43251;
	int d1=num%10;
	num=num/10;
	int d2=num%10;
	num=num/10;
	int d3=num%10;
	num=num/10;
	int d4=num%10;
	num=num/10;
	int d5=num%10;
	int sum=d1+d2+d3+d4+d5;
	printf("The sum of all digits of the number is : %d\n",sum);
	return 0;
}