#include<stdio.h>
int main()
{
	int num=79812;
	int d1=num%10;
	num=num/10;
	int d2=num%10;
	num=num/10;
	int d3=num%10;
	num=num/10;
	int d4=num%10;
	num=num/10;
	int d5=num%10;
	printf("the reverse of number is:%d %d %d %d %d\n",d1,d2,d3,d4,d5);
	return 0;
}