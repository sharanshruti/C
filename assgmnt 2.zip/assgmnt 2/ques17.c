#include<stdio.h>
int main()
{
	int num=43251;
	int d1=num%10;
	num=num/10;
	int d2=num%10;
	num=num/10;
	int d3=num%10;
	num=num/10;
	int d4=num%10;
	num=num/10;
	int d5=num%10;
	int product=d1*d2*d3*d4*d5;
	printf("The product of all digits of the number is : %d\n",product);
	return 0;
}