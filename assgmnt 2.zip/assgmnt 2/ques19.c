#include<stdio.h>
int main()
{
	int num=76324;
	int d1=num%10;
	num=num/10;
	int d2=num%10;
	num=num/10;
	int d3=num%10;
	num=num/10;
	int d4=num%10;
	num=num/10;
	int d5=num%10;
	int rev=d1*10000+d2*1000+d3*100+d4*10+d5;
	printf("%d",rev);
	num==rev ? printf("y\n") : printf("n\n");
	return 0;
}