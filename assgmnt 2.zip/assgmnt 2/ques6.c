#include<stdio.h>
int main()
{
	int p=100000,r=15,t=2;
	double si=(p*r*t)/100;
	printf("The simple interest is: %g\n",si);
	return 0;
}