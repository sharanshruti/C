#include<stdio.h>
int main()
{
	int f=40;
	double c=((f-32)*5)/9.0;
	printf("the temp in celsius is: %g\n",c);
	return 0;
}