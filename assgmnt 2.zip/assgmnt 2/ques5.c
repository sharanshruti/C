#include<stdio.h>
#include<math.h>

int main()
{
	int a=3,b=4,c=5;
	int s=(a+b+c)/2;
	int area=sqrt(s*(s-a)*(s-b)*(s-c));
	printf("area of triangle: %d\n",area);
	return 0;

}