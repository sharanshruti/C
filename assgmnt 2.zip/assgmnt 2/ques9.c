#include<stdio.h>
int main()
{
	double circum=6.28;//circum=2pir
	double r=circum/(2*3.14);
	double area=3.14*r*r;
	printf("the area from given circumference is: %g\n",area);
	return 0;

}