#include<stdio.h>
int main()
{
	int a=2,b=5,c=5,d=10,e=8;
	double avg=(a+b+c+d+e)/5.0;
	printf("the avg of 5 numbers is: %g\n",avg);
	return 0;
}