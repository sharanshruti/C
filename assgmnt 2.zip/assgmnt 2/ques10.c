#include<stdio.h>
int main()
{
	int u=5,a=4,t=2;
	int v=u+a*t;
	printf("the final velocity is: %d\n",v);
	return 0;
}