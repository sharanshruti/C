#include<stdio.h>
int main()
{
	double p=10000,r=15,t=2;//time is 2yrs so two calculations as no loop to be used.
	double si=(p*r*1)/100.0;
	double p1=p+si;
	double sii=(p1*r*1)/100.0;
	double ci=p1+sii;
	printf("Compound interest is:%g\n",ci);
	return 0;
}