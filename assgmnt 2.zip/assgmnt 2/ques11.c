#include<stdio.h>
int main()
{
	int u=5,a=4,t=2;
	double s=u*t+0.5*a*t*t;
	printf("the displacement is: %g\n",s);
	return 0;
}