#include<stdio.h>
int main()
{
	int c=40;
	double f=(9*c)/5+32;
	printf("the temp in farheniet is: %g\n",f);
	return 0;
}