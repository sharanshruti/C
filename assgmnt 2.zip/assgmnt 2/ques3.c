#include<stdio.h>
int main()
{
	int r=1;
	double area=3.14*r*r;
	printf("The area of the circle is: %g\n",area);
	return 0;
}