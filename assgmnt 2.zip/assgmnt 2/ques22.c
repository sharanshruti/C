#include<stdio.h>
int main()
{
	int a=20, b=20;
	a>b ? printf("%d\n",a):printf("%d\n",b);
	return 0;
}