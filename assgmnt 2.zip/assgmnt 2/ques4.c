#include<stdio.h>
int main()
{
	int l=10,b=5;
	double area=l*b;
	printf("the area of rectangle is : %g\n",area);
	return 0;
}