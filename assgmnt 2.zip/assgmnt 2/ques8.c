#include<stdio.h>
#include<math.h>
int main()
{
	int a=6,b=5,c=1;//6x2+5x+1
	double x1= (-b+sqrt(b*b-4*a*c))/(2*a);
	double x2= (-b-sqrt(b*b-4*a*c))/(2*a);
	printf("Solution of the quadratic equation: %g %g\n ",x1,x2);
	return 0;

}