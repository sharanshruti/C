#include<stdio.h>

int main(void)
{
	int my_first_variable;
	int mySecondVariable;
	int MyThirdVariable;
	int char;
	int n;
	int number;
	int _;
	int _number_;
	int 2months;
	int months2;
	int months_2;
	int months 2;
	int months two;
	int moths?;	
	return 0;

}