#include<stdio.h>

int main(void)
{
	int n=5;
	printf("The value of n is %d.\n",n);
	printf("The address of n is %p.\n", &n);
	return 0;

}