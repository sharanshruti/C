#include<stdio.h>
int main(void)
{
	char myChar = 'C';
	unsigned char myUnsignedChar = 'C';
	signed char mySignedChar = 'C';
	int myInt = -1 * 'C';
	unsigned int myUnsignedInt = 0x5E;
	short myShort = -1 * 'C';
	unsigned short myUnsignedShort = 010;
	long myLong = -10000000;
	unsigned long myUnsignedLong = 10000000000;
	float myFloat = 0.325;
	double myDouble = 1.5e-3;
	long double myLongDouble = 3.2e30;
	printf("%ld %ld \n", sizeof(myChar), sizeof(char));
	printf("%ld %ld \n",sizeof(myUnsignedChar), sizeof(unsigned char));
	printf("%ld %ld \n",sizeof(mySignedChar), sizeof(signed char));
	printf("%ld %ld \n",sizeof(myInt),sizeof(int));
	printf("%ld %ld \n",sizeof(myUnsignedInt),sizeof(unsigned int));
	printf("%ld %ld \n",sizeof(myShort),sizeof(short));
	printf("%ld %ld \n",sizeof(myUnsignedShort),sizeof(unsigned short));
	printf("%ld %ld \n",sizeof(myLong),sizeof(long));
	printf("%ld %ld \n",sizeof(myUnsignedLong),sizeof(unsigned long));
	printf("%ld %ld \n",sizeof(myFloat),sizeof(float));
	printf("%ld %ld \n",sizeof(myDouble),sizeof(double));
	printf("%ld %ld \n",sizeof(myLongDouble),sizeof(long double));
	return 0;
}